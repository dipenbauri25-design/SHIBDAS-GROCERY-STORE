package com.shibdas.grocery

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.Image
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.layout.ContentScale
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

data class Product(
    val id: Int, val name: String, val category: String,
    val price: Double, val unit: String, val stock: Int
)

data class CartItem(val product: Product, val qty: Int)

private val products = listOf(
    Product(1,"Basmati Rice","Rice & Grains",85.0,"1 kg",30),
    Product(2,"Toor Dal","Dal & Pulses",140.0,"1 kg",25),
    Product(3,"Mustard Oil","Oil",165.0,"1 L",20),
    Product(4,"Aashirvaad Atta","Flour",62.0,"1 kg",40),
    Product(5,"Sugar","Essentials",48.0,"1 kg",50),
    Product(6,"Tea","Beverages",120.0,"250 g",18),
    Product(7,"Biscuits","Snacks",30.0,"Pack",35),
    Product(8,"Salt","Essentials",25.0,"1 kg",60)
)

enum class Screen { HOME, CART, ORDERS, PROFILE, ADMIN }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ShibdasApp() }
    }
}

@Composable
fun ShibdasApp() {
    var screen by remember { mutableStateOf(Screen.HOME) }
    var cart by remember { mutableStateOf(listOf<CartItem>()) }
    var search by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("All") }
    var snackbar by remember { mutableStateOf("") }
    val categories = listOf("All","Rice & Grains","Dal & Pulses","Oil","Flour","Essentials","Beverages","Snacks")

    val filtered = products.filter {
        (category=="All" || it.category==category) &&
        it.name.contains(search, ignoreCase = true)
    }

    MaterialTheme(colorScheme = lightColorScheme(primary = Color(0xFF176B3A))) {
        Scaffold(
            topBar = {
                if (screen != Screen.ADMIN) {
                    TopAppBar(
                        title = { Text("Shibdas Grocery Store", fontWeight = FontWeight.Bold) },
                        actions = {
                            IconButton(onClick = { screen = Screen.CART }) {
                                BadgedBox(badge = { if(cart.sumOf{it.qty}>0) Badge { Text(cart.sumOf{it.qty}.toString()) } }) {
                                    Icon(Icons.Default.ShoppingCart, null)
                                }
                            }
                        }
                    )
                }
            },
            bottomBar = {
                if (screen != Screen.ADMIN) NavigationBar {
                    NavItem("Home", Icons.Default.Home, screen==Screen.HOME){screen=Screen.HOME}
                    NavItem("Cart", Icons.Default.ShoppingCart, screen==Screen.CART){screen=Screen.CART}
                    NavItem("Orders", Icons.Default.Receipt, screen==Screen.ORDERS){screen=Screen.ORDERS}
                    NavItem("Profile", Icons.Default.Person, screen==Screen.PROFILE){screen=Screen.PROFILE}
                }
            },
            snackbarHost = { SnackbarHost(remember { SnackbarHostState() }) }
        ) { pad ->
            Box(Modifier.padding(pad)) {
                when(screen) {
                    Screen.HOME -> HomeScreen(search, {search=it}, category, {category=it}, categories, filtered,
                        cart, { p -> cart = addToCart(cart,p); snackbar="Added ${p.name}" })
                    Screen.CART -> CartScreen(cart, {p -> cart=addToCart(cart,p)}, {p -> cart=removeFromCart(cart,p)},
                        { screen=Screen.HOME }, { screen=Screen.ORDERS })
                    Screen.ORDERS -> OrdersScreen()
                    Screen.PROFILE -> ProfileScreen { screen=Screen.ADMIN }
                    Screen.ADMIN -> AdminScreen { screen=Screen.HOME }
                }
            }
        }
    }
}

@Composable
fun RowScope.NavItem(label:String, icon:androidx.compose.ui.graphics.vector.ImageVector, selected:Boolean, onClick:()->Unit) {
    NavigationBarItem(selected=selected,onClick=onClick,icon={Icon(icon,null)},label={Text(label)})
}

fun addToCart(cart:List<CartItem>, p:Product):List<CartItem> =
    cart.map { if(it.product.id==p.id) it.copy(qty=it.qty+1) else it }.let { updated ->
        if(updated.none{it.product.id==p.id}) updated + CartItem(p,1) else updated
    }
fun removeFromCart(cart:List<CartItem>, p:Product):List<CartItem> =
    cart.flatMap { if(it.product.id==p.id && it.qty>1) listOf(it.copy(qty=it.qty-1))
                   else if(it.product.id==p.id) emptyList() else listOf(it) }

@Composable
fun HomeScreen(search:String,onSearch:(String)->Unit, category:String,onCategory:(String)->Unit,
               categories:List<String>, list:List<Product>, cart:List<CartItem>, add:(Product)->Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) {
        item {
            Card(colors=CardDefaults.cardColors(containerColor=Color(0xFFE8F5E9))) {
                Column(Modifier.padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Image(
                        painter = painterResource(R.drawable.shibdas_logo),
                        contentDescription = "Shibdas Grocery Store logo",
                        modifier = Modifier.fillMaxWidth().height(150.dp),
                        contentScale = ContentScale.Fit
                    )
                    Text("Shop Smart. Pickup Fast.",fontSize=22.sp,fontWeight=FontWeight.Bold)
                    Text("Order online and collect your groceries from our store.")
                }
            }
        }
        item {
            OutlinedTextField(search,onSearch,Modifier.fillMaxWidth(),placeholder={Text("Search groceries…")},
                leadingIcon={Icon(Icons.Default.Search,null)},singleLine=true)
        }
        item {
            LazyRow(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                items(categories) { c ->
                    FilterChip(selected=c==category,onClick={onCategory(c)},label={Text(c)})
                }
            }
        }
        items(list) { p ->
            ProductCard(p, cart.firstOrNull{it.product.id==p.id}?.qty ?: 0, add)
        }
    }
}

@Composable
fun ProductCard(p:Product, qty:Int, add:(Product)->Unit) {
    Card {
        Row(Modifier.fillMaxWidth().padding(14.dp),verticalAlignment=Alignment.CenterVertically) {
            Box(Modifier.size(58.dp).background(Color(0xFFF1F8E9)),contentAlignment=Alignment.Center) {
                Text("🛒",fontSize=28.sp)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(p.name,fontWeight=FontWeight.Bold)
                Text("${p.unit} • ₹${p.price.roundToInt()}")
                Text(if(p.stock>0) "In stock" else "Out of stock", color=if(p.stock>0) Color(0xFF2E7D32) else Color.Red)
            }
            if(qty>0) Text("$qty",fontWeight=FontWeight.Bold,modifier=Modifier.padding(8.dp))
            Button(onClick={add(p)},enabled=p.stock>0){Text("ADD")}
        }
    }
}

@Composable
fun CartScreen(cart:List<CartItem>,add:(Product)->Unit,remove:(Product)->Unit,shop:()->Unit,orders:()->Unit) {
    val total=cart.sumOf{it.product.price*it.qty}
    LazyColumn(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
        item { Text("Your Cart",fontSize=26.sp,fontWeight=FontWeight.Bold) }
        if(cart.isEmpty()) item { Text("Your cart is empty.") }
        items(cart) { item ->
            Card { Row(Modifier.fillMaxWidth().padding(12.dp),verticalAlignment=Alignment.CenterVertically) {
                Column(Modifier.weight(1f)){Text(item.product.name,fontWeight=FontWeight.Bold);Text("₹${item.product.price.roundToInt()} × ${item.qty}")}
                OutlinedButton(onClick={remove(item.product)}){Text("−")}
                Text("${item.qty}",Modifier.padding(horizontal=10.dp))
                OutlinedButton(onClick={add(item.product)}){Text("+")}
            }}
        }
        if(cart.isNotEmpty()) item {
            HorizontalDivider()
            Text("Total: ₹${total.roundToInt()}",fontSize=22.sp,fontWeight=FontWeight.Bold)
            Text("Pickup: Shibdas Grocery Store",fontWeight=FontWeight.SemiBold)
            Spacer(Modifier.height(6.dp))
            Button(onClick=shop,Modifier.fillMaxWidth()){Text("CHECKOUT & PAY")}
        }
    }
}

@Composable
fun OrdersScreen() {
    Column(Modifier.fillMaxSize().padding(20.dp),verticalArrangement=Arrangement.spacedBy(14.dp)) {
        Text("My Orders",fontSize=26.sp,fontWeight=FontWeight.Bold)
        Card {
            Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
                Text("Order #SGS-1001",fontWeight=FontWeight.Bold)
                Text("Status: READY FOR PICKUP",color=Color(0xFF176B3A),fontWeight=FontWeight.Bold)
                Text("Pickup at Shibdas Grocery Store")
                Text("Payment: UPI")
            }
        }
    }
}

@Composable
fun ProfileScreen(openAdmin:()->Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
        Text("Profile",fontSize=26.sp,fontWeight=FontWeight.Bold)
        OutlinedTextField("","",Modifier.fillMaxWidth(),label={Text("Mobile Number")})
        Button(onClick={},Modifier.fillMaxWidth()){Text("SAVE PROFILE")}
        Spacer(Modifier.height(20.dp))
        OutlinedButton(onClick=openAdmin,Modifier.fillMaxWidth()){Text("ADMIN PANEL (DEMO)")}
    }
}

@Composable
fun AdminScreen(back:()->Unit) {
    var tab by remember { mutableStateOf(0) }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment=Alignment.CenterVertically) {
            IconButton(onClick=back){Icon(Icons.Default.ArrowBack,null)}
            Text("Admin Dashboard",fontSize=24.sp,fontWeight=FontWeight.Bold)
        }
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)) {
            StatCard("Orders","12")
            StatCard("Sales","₹8,450")
            StatCard("Products","128")
        }
        Spacer(Modifier.height(16.dp))
        Text("Today's Orders",fontSize=20.sp,fontWeight=FontWeight.Bold)
        AdminOrder("SGS-1001","Rahul","₹560","PAID • READY")
        AdminOrder("SGS-1002","Customer","₹320","CASH • PREPARING")
        AdminOrder("SGS-1003","Customer","₹890","PAID • PLACED")
    }
}

@Composable
fun RowScope.StatCard(title:String,value:String) {
    Card(Modifier.weight(1f)) { Column(Modifier.padding(12.dp)){Text(title);Text(value,fontSize=20.sp,fontWeight=FontWeight.Bold)} }
}
@Composable
fun AdminOrder(id:String,name:String,total:String,status:String) {
    Card(Modifier.fillMaxWidth().padding(vertical=5.dp)) {
        Row(Modifier.fillMaxWidth().padding(14.dp),verticalAlignment=Alignment.CenterVertically) {
            Column(Modifier.weight(1f)){Text(id,fontWeight=FontWeight.Bold);Text(name);Text(total)}
            Column(horizontalAlignment=Alignment.End){Text(status,fontWeight=FontWeight.Bold);Button(onClick={}){Text("UPDATE")}}
        }
    }
}
